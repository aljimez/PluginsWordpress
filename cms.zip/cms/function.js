jQuery(function($) {
    $("#side").click(function() {
      $('#slidable').toggleClass("open");
    });
  })
  